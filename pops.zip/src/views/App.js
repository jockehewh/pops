import React from 'react';
import logo from '../logo.svg';
import './App.css';
import Login from './login.js';

function App() {
  return (
    <div className="App">
      <Login />
    </div>
  );
}

export default App;
